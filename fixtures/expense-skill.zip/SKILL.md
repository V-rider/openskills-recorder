# Expense Demo

> Submit expense report on demo app

## When to use
When submitting expenses on the demo form

## Parameters

- **email** (string): example `test@example.com`
- **amount** (string): example `42.50`

## Steps

4 steps — see skill.json
